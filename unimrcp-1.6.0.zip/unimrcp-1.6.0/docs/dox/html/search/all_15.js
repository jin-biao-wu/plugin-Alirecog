var searchData=
[
  ['waiting',['waiting',['../structrtp__termination__slot__t.html#aa53527333eaad2d8f2da6ceb62df57af',1,'rtp_termination_slot_t']]],
  ['waiting_5ffor_5fchannel',['waiting_for_channel',['../structmrcp__channel__t.html#a43053f776640a457cac6f541763dae6d',1,'mrcp_channel_t']]],
  ['waiting_5ffor_5ftermination',['waiting_for_termination',['../structmrcp__channel__t.html#afae910f1f322079e842e49385fab5cb9',1,'mrcp_channel_t']]],
  ['waveform_5furi',['waveform_uri',['../structmrcp__recog__header__t.html#a23a67e0e4698aec7d2dd6c41e3eaf2fa',1,'mrcp_recog_header_t::waveform_uri()'],['../structmrcp__verifier__header__t.html#addd6665db3320b6bbba046709c6e66b9',1,'mrcp_verifier_header_t::waveform_uri()']]],
  ['weight',['weight',['../structmrcp__recog__header__t.html#a402c194715ad5b9918f04cacebcf54b8',1,'mrcp_recog_header_t']]],
  ['write_5fframe',['write_frame',['../structmpf__audio__stream__vtable__t.html#a28f5e78eb77d2caa682c22eac7ca93da',1,'mpf_audio_stream_vtable_t']]],
  ['write_5fhandle',['write_handle',['../structmpf__audio__file__descriptor__t.html#a3b52054921205cb89176b1930083d8c8',1,'mpf_audio_file_descriptor_t']]]
];
